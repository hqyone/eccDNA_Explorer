#!/bin/sh

../source/fastuniq -i input_list.txt -t q -o output_1.fastq -p output_2.fastq -c 1
